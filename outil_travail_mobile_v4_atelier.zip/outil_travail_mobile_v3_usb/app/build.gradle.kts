plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.afribdstudio.outiltravailmobile"; compileSdk = 35
 defaultConfig { applicationId = "com.afribdstudio.outiltravailmobile"; minSdk = 23; targetSdk = 35; versionCode = 3; versionName = "3.0-USB-alpha" }
}
