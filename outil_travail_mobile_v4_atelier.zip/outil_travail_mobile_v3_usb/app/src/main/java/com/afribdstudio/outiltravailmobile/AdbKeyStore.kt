package com.afribdstudio.outiltravailmobile

import android.content.Context
import java.io.File
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.util.Base64

/**
 * Stocke une paire de clés RSA 2048 bits réutilisée pour l'authentification ADB,
 * comme le fait le client "adb" officiel (~/.android/adbkey). La clé est générée
 * une seule fois sur ce téléphone technicien et conservée dans le stockage privé
 * de l'application. Le téléphone client doit, lui, accepter explicitement cette
 * clé (fenêtre "Autoriser le débogage USB ?") la première fois qu'il la voit.
 */
object AdbKeyStore {
    private const val PRIV_FILE = "adb_host_key.priv"
    private const val PUB_FILE = "adb_host_key.pub"

    fun loadOrCreate(context: Context): KeyPair {
        val dir = context.filesDir
        val privFile = File(dir, PRIV_FILE)
        val pubFile = File(dir, PUB_FILE)
        if (privFile.exists() && pubFile.exists()) {
            val kf = KeyFactory.getInstance("RSA")
            val priv = kf.generatePrivate(PKCS8EncodedKeySpec(privFile.readBytes())) as RSAPrivateKey
            val pub = kf.generatePublic(X509EncodedKeySpec(pubFile.readBytes())) as RSAPublicKey
            return KeyPair(pub, priv)
        }
        val gen = KeyPairGenerator.getInstance("RSA")
        gen.initialize(2048)
        val pair = gen.generateKeyPair()
        privFile.writeBytes(pair.private.encoded)
        pubFile.writeBytes(pair.public.encoded)
        return pair
    }

    /**
     * Construit le blob de clé publique au format attendu par adbd (structure
     * mincrypt RSAPublicKey : len, n0inv, n[], rr[], exposant), encodé en Base64
     * puis suivi d'un commentaire "utilisateur@hôte" et d'un octet nul final —
     * exactement le format produit par le "adb" officiel pour ~/.android/adbkey.pub.
     * À vérifier une fois le projet ouvert dans Android Studio (avec accès à un
     * vrai appareil pour tester le handshake), car cette portion ne peut pas être
     * validée sans matériel.
     */
    fun publicKeyToAdbBlob(publicKey: RSAPublicKey, comment: String = "atelier@outil-reparation"): ByteArray {
        val n = publicKey.modulus
        val words = n.bitLength() / 32 + if (n.bitLength() % 32 != 0) 1 else 0
        val wordCount = maxOf(words, 64) // 2048 bits / 32 = 64 mots

        val two32 = BigInteger.ONE.shiftLeft(32)
        val n0 = n.mod(two32)
        val n0inv = two32.subtract(n0.modInverse(two32)).mod(two32)

        val r = BigInteger.ONE.shiftLeft(32 * wordCount)
        val rr = r.multiply(r).mod(n)

        fun toWords(value: BigInteger): IntArray {
            val arr = IntArray(wordCount)
            var v = value
            for (i in 0 until wordCount) {
                arr[i] = v.and(BigInteger.valueOf(0xFFFFFFFFL)).toLong().toInt()
                v = v.shiftRight(32)
            }
            return arr
        }

        val nWords = toWords(n)
        val rrWords = toWords(rr)
        val exponent = publicKey.publicExponent.toInt()

        val buffer = java.nio.ByteBuffer.allocate(4 + 4 + wordCount * 4 + wordCount * 4 + 4)
            .order(java.nio.ByteOrder.LITTLE_ENDIAN)
        buffer.putInt(wordCount)
        buffer.putInt(n0inv.toLong().toInt())
        nWords.forEach { buffer.putInt(it) }
        rrWords.forEach { buffer.putInt(it) }
        buffer.putInt(exponent)

        val base64 = Base64.getEncoder().encodeToString(buffer.array())
        return (base64 + " " + comment + "\u0000").toByteArray(Charsets.UTF_8)
    }
}
