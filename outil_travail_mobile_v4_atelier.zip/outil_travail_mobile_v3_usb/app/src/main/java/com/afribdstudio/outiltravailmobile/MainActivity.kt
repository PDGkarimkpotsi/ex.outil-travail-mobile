package com.afribdstudio.outiltravailmobile

import android.app.*
import android.content.*
import android.hardware.usb.*
import android.net.Uri
import android.os.*
import android.provider.OpenableColumns
import android.webkit.*
import org.json.JSONArray
import org.json.JSONObject

private const val USB_IF_CLASS = 0xFF
private const val USB_IF_SUBCLASS = 0x42
private const val USB_IF_PROTOCOL_ADB = 0x01
private const val USB_IF_PROTOCOL_FASTBOOT = 0x03
private const val REQUEST_PICK_FIRMWARE = 4201

class MainActivity : Activity() {
    private lateinit var usbManager: UsbManager
    private lateinit var web: WebView
    private val actionUsbPermission = "com.afribdstudio.outiltravailmobile.USB_PERMISSION"

    private var firmwareUri: Uri? = null
    private var firmwareSize: Long = -1

    private var activeAdb: AdbClient? = null
    private var activeAdbDeviceName: String? = null

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                actionUsbPermission -> {
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    @Suppress("DEPRECATION")
                    val device: UsbDevice? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java) else intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
                    val msg = if (granted && device != null) "Autorisation accordée pour ${device.deviceName}. Inspection des descripteurs possible." else "Autorisation USB refusée. Aucune inspection effectuée."
                    web.post { web.evaluateJavascript("window.onUsbPermissionResult(${granted}, ${JSONObject.quote(msg)});", null) }
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    activeAdb = null; activeAdbDeviceName = null
                    web.post { web.evaluateJavascript("window.onUsbDetached && window.onUsbDetached();", null) }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(USB_SERVICE) as UsbManager
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = false
        web.addJavascriptInterface(UsbBridge(), "AndroidUSB")
        web.webViewClient = WebViewClient()
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        val filter = IntentFilter().apply { addAction(actionUsbPermission); addAction(UsbManager.ACTION_USB_DEVICE_DETACHED) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(usbReceiver, filter, RECEIVER_NOT_EXPORTED) else registerReceiver(usbReceiver, filter)
    }

    override fun onDestroy() { try { unregisterReceiver(usbReceiver) } catch (_: Exception) {}; web.destroy(); super.onDestroy() }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PICK_FIRMWARE && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val (name, size) = queryNameAndSize(uri)
            firmwareUri = uri; firmwareSize = size
            web.post { web.evaluateJavascript("window.onFirmwarePicked(${JSONObject.quote(name)}, $size);", null) }
        }
    }

    private fun queryNameAndSize(uri: Uri): Pair<String, Long> {
        var name = "fichier_image"; var size = -1L
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
            if (c.moveToFirst()) {
                if (nameIdx >= 0) name = c.getString(nameIdx) ?: name
                if (sizeIdx >= 0) size = c.getLong(sizeIdx)
            }
        }
        if (size < 0) {
            try { contentResolver.openFileDescriptor(uri, "r")?.use { size = it.statSize } } catch (_: Exception) {}
        }
        return name to size
    }

    private fun findDevice(name: String): UsbDevice =
        usbManager.deviceList.values.firstOrNull { it.deviceName == name }
            ?: throw IllegalStateException("Appareil introuvable ou débranché : $name")

    private fun findInterface(device: UsbDevice, protocol: Int): UsbInterface? {
        for (i in 0 until device.interfaceCount) {
            val intf = device.getInterface(i)
            if (intf.interfaceClass == USB_IF_CLASS && intf.interfaceSubclass == USB_IF_SUBCLASS && intf.interfaceProtocol == protocol) return intf
        }
        return null
    }

    private fun bulkEndpoints(intf: UsbInterface): Pair<UsbEndpoint, UsbEndpoint> {
        var inEp: UsbEndpoint? = null; var outEp: UsbEndpoint? = null
        for (i in 0 until intf.endpointCount) {
            val ep = intf.getEndpoint(i)
            if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
            if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
        }
        if (inEp == null || outEp == null) throw IllegalStateException("Endpoints bulk introuvables sur cette interface.")
        return inEp to outEp
    }

    private fun <T> withFastboot(deviceName: String, block: (FastbootClient) -> T): T {
        val device = findDevice(deviceName)
        val intf = findInterface(device, USB_IF_PROTOCOL_FASTBOOT)
            ?: throw IllegalStateException("Aucune interface Fastboot détectée. Le téléphone client doit être démarré en mode bootloader/fastboot.")
        val connection = usbManager.openDevice(device)
            ?: throw IllegalStateException("Impossible d'ouvrir la connexion USB (autorisation Android manquante ?).")
        if (!connection.claimInterface(intf, true)) throw IllegalStateException("Impossible de réserver l'interface Fastboot.")
        try {
            val (inEp, outEp) = bulkEndpoints(intf)
            return block(FastbootClient(connection, inEp, outEp))
        } finally {
            try { connection.releaseInterface(intf) } catch (_: Exception) {}
            connection.close()
        }
    }

    private fun getOrConnectAdb(deviceName: String): AdbClient {
        activeAdb?.let { if (activeAdbDeviceName == deviceName) return it }
        val device = findDevice(deviceName)
        val intf = findInterface(device, USB_IF_PROTOCOL_ADB)
            ?: throw IllegalStateException("Aucune interface ADB détectée. Le débogage USB doit être activé sur le téléphone client.")
        val connection = usbManager.openDevice(device)
            ?: throw IllegalStateException("Impossible d'ouvrir la connexion USB (autorisation Android manquante ?).")
        if (!connection.claimInterface(intf, true)) throw IllegalStateException("Impossible de réserver l'interface ADB.")
        val (inEp, outEp) = bulkEndpoints(intf)
        val keyPair = AdbKeyStore.loadOrCreate(this)
        val client = AdbClient(connection, inEp, outEp, keyPair)
        client.connect()
        activeAdb = client; activeAdbDeviceName = deviceName
        return client
    }

    /** Construit un rapport de diagnostic à partir de commandes shell en lecture seule, avec des suggestions. */
    private fun runAdbDiagnostic(client: AdbClient): String {
        val out = StringBuilder()
        val suggestions = StringBuilder()

        val battery = runCatching { client.shell("dumpsys battery") }.getOrDefault("(indisponible)")
        out.appendLine("--- Batterie ---").appendLine(battery.trim()).appendLine()
        Regex("level:\\s*(\\d+)").find(battery)?.groupValues?.get(1)?.toIntOrNull()?.let {
            if (it in 1..15) suggestions.appendLine("• Batterie à $it % : recharge avant tout flashage (coupure pendant un flash = risque de brick).")
        }
        Regex("health:\\s*(\\d+)").find(battery)?.groupValues?.get(1)?.toIntOrNull()?.let { h ->
            when (h) { 4 -> suggestions.appendLine("• État batterie signalé « morte » : remplacement probable à prévoir.")
                3 -> suggestions.appendLine("• Surchauffe signalée : laisser refroidir avant intervention.")
                5 -> suggestions.appendLine("• Surtension signalée : vérifier le chargeur/câble utilisé par le client.") }
        }

        val storage = runCatching { client.shell("df /data") }.getOrDefault("(indisponible)")
        out.appendLine("--- Stockage (/data) ---").appendLine(storage.trim()).appendLine()
        Regex("(\\d{1,3})%").find(storage)?.groupValues?.get(1)?.toIntOrNull()?.let {
            if (it >= 90) suggestions.appendLine("• Stockage plein à $it % : proposer au client de libérer de l'espace (cache, photos) — cause fréquente de lenteurs.")
        }

        val props = runCatching { client.shell("getprop ro.product.model; getprop ro.build.version.release; getprop ro.build.version.security_patch") }.getOrDefault("(indisponible)")
        out.appendLine("--- Identification ---").appendLine(props.trim()).appendLine()

        val uptime = runCatching { client.shell("cat /proc/uptime") }.getOrDefault("")
        uptime.trim().split(" ").firstOrNull()?.toDoubleOrNull()?.let {
            val hours = it / 3600.0
            out.appendLine("--- Disponibilité ---").appendLine("Temps depuis le dernier démarrage : ${"%.1f".format(hours)} h").appendLine()
            if (hours < 0.05) suggestions.appendLine("• Le téléphone vient de redémarrer : vérifier s'il s'agit d'un redémarrage en boucle (bootloop).")
        }

        if (suggestions.isEmpty()) suggestions.append("Aucune anomalie simple détectée dans ces relevés. Un diagnostic matériel plus poussé peut rester nécessaire.")
        out.appendLine("--- Suggestions ---").append(suggestions)
        return out.toString()
    }

    inner class UsbBridge {
        @JavascriptInterface fun listDevices(): String {
            val arr = JSONArray()
            usbManager.deviceList.values.forEach { d ->
                arr.put(JSONObject().apply {
                    put("name", d.deviceName); put("vendorId", d.vendorId); put("productId", d.productId)
                    put("product", d.productName ?: "Appareil USB"); put("manufacturer", d.manufacturerName ?: "Inconnu")
                    put("class", d.deviceClass); put("subclass", d.deviceSubclass); put("protocol", d.deviceProtocol)
                    put("interfaces", d.interfaceCount); put("permission", usbManager.hasPermission(d))
                })
            }
            return arr.toString()
        }

        @JavascriptInterface fun requestPermission(deviceName: String): Boolean {
            val device = usbManager.deviceList.values.firstOrNull { it.deviceName == deviceName } ?: return false
            if (usbManager.hasPermission(device)) {
                web.post { web.evaluateJavascript("window.onUsbPermissionResult(true, 'Autorisation déjà accordée.');", null) }
                return true
            }
            val pi = PendingIntent.getBroadcast(this@MainActivity, device.deviceId, Intent(actionUsbPermission).setPackage(packageName), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
            usbManager.requestPermission(device, pi)
            return true
        }

        @JavascriptInterface fun inspectDevice(deviceName: String): String {
            val d = usbManager.deviceList.values.firstOrNull { it.deviceName == deviceName } ?: return "Appareil introuvable ou débranché."
            if (!usbManager.hasPermission(d)) return "Autorisation manquante. Appuie d’abord sur Demander l’autorisation Android."
            val out = StringBuilder()
            out.appendLine("APPAREIL USB — INSPECTION EN LECTURE SEULE")
            out.appendLine("Nom système : ${d.deviceName}")
            out.appendLine("Fabricant : ${d.manufacturerName ?: "Non fourni"}")
            out.appendLine("Produit : ${d.productName ?: "Non fourni"}")
            out.appendLine("VID : 0x${d.vendorId.toString(16).uppercase()}   PID : 0x${d.productId.toString(16).uppercase()}")
            out.appendLine("Classe : ${d.deviceClass} / sous-classe : ${d.deviceSubclass} / protocole : ${d.deviceProtocol}")
            out.appendLine("Interfaces : ${d.interfaceCount}")
            var hasAdb = false; var hasFastboot = false
            for (i in 0 until d.interfaceCount) {
                val intf = d.getInterface(i)
                out.appendLine("\nInterface $i — classe ${intf.interfaceClass}, sous-classe ${intf.interfaceSubclass}, protocole ${intf.interfaceProtocol}")
                if (intf.interfaceClass == USB_IF_CLASS && intf.interfaceSubclass == USB_IF_SUBCLASS) {
                    if (intf.interfaceProtocol == USB_IF_PROTOCOL_ADB) { hasAdb = true; out.appendLine("  → Interface ADB (débogage USB déjà activé côté client).") }
                    if (intf.interfaceProtocol == USB_IF_PROTOCOL_FASTBOOT) { hasFastboot = true; out.appendLine("  → Interface Fastboot (téléphone en mode bootloader).") }
                }
                for (e in 0 until intf.endpointCount) {
                    val ep = intf.getEndpoint(e)
                    val dir = if (ep.direction == UsbConstants.USB_DIR_IN) "ENTRÉE" else "SORTIE"
                    out.appendLine("  Endpoint $e : $dir, type=${ep.type}, maxPacket=${ep.maxPacketSize}")
                }
            }
            out.appendLine("\nRésultat : descripteurs USB consultés. Aucun fichier, compte, mot de passe ou contenu privé n’a été lu.")
            out.appendLine("\n--- Diagnostic rapide ---")
            when {
                hasFastboot -> out.appendLine("Téléphone en mode Fastboot : utilise le module « Flashage officiel (Fastboot) » ci-dessous (fonctionne seulement si le bootloader est déjà déverrouillé).")
                hasAdb -> out.appendLine("Téléphone en mode ADB : utilise le module « Diagnostic ADB » ci-dessous.")
                else -> out.appendLine("Aucune interface ADB/Fastboot détectée (le téléphone est probablement en mode normal MTP/PTP ou chargement seul). Pour flasher : redémarre-le en bootloader (combinaison de touches du fabricant). Pour un diagnostic ADB : demande au client d'activer le débogage USB dans les options développeur, puis accepte la demande affichée sur son écran.")
            }
            return out.toString()
        }

        // --- Fastboot ---
        @JavascriptInterface fun fastbootGetAll(deviceName: String): String = withFastboot(deviceName) { client ->
            client.getAllVars().entries.joinToString("\n") { "${it.key}: ${it.value}" }
        }

        @JavascriptInterface fun fastbootReboot(deviceName: String, toBootloader: Boolean) {
            withFastboot(deviceName) { client -> if (toBootloader) client.rebootBootloader() else client.reboot() }
        }

        @JavascriptInterface fun pickFirmwareFile() {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(intent, REQUEST_PICK_FIRMWARE)
        }

        @JavascriptInterface fun fastbootFlashPartition(deviceName: String, partition: String): String {
            val uri = firmwareUri ?: return "Choisis d'abord un fichier image."
            if (firmwareSize <= 0) return "Taille de fichier invalide, choisis à nouveau le fichier."
            return withFastboot(deviceName) { client ->
                contentResolver.openInputStream(uri)?.use { input ->
                    client.flash(partition, firmwareSize.toInt(), input)
                } ?: "Impossible de lire le fichier choisi."
            }
        }

        @JavascriptInterface fun fastbootFactoryReset(deviceName: String): String = withFastboot(deviceName) { client ->
            val r1 = client.erase("userdata")
            val r2 = client.erase("cache")
            client.reboot()
            "userdata : $r1\ncache : $r2\nRedémarrage demandé. Le téléphone affichera l'écran de configuration et demandera le compte Google/Samsung précédemment synchronisé (protection FRP) — le client doit se reconnecter lui-même."
        }

        // --- ADB ---
        @JavascriptInterface fun adbConnect(deviceName: String): String = getOrConnectAdb(deviceName).let { "Connecté en ADB." }

        @JavascriptInterface fun adbDiagnostic(deviceName: String): String = runAdbDiagnostic(getOrConnectAdb(deviceName))

        @JavascriptInterface fun adbReboot(deviceName: String, mode: String) { getOrConnectAdb(deviceName).reboot(mode) }
    }
}
