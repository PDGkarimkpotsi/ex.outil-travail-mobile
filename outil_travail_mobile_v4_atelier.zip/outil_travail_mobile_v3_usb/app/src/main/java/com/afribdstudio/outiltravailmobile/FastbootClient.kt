package com.afribdstudio.outiltravailmobile

import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import java.io.InputStream
import java.nio.charset.Charset

/**
 * Implémentation minimale du protocole FASTBOOT par transferts USB "bulk".
 *
 * Fastboot est le protocole OFFICIEL utilisé par les outils constructeurs
 * (Odin et équivalents, "fastboot" des Android platform-tools) pour
 * réinstaller un firmware. Il ne fonctionne QUE si :
 *  - le téléphone client est déjà démarré en mode bootloader/fastboot, et
 *  - son propriétaire a déjà activé le déverrouillage OEM (OEM unlock)
 *    et déverrouillé le bootloader lui-même au préalable.
 * Si le bootloader est verrouillé, le téléphone répond FAIL à toute
 * commande flash/erase : cette classe ne contourne aucune protection.
 */
class FastbootProtocolException(message: String) : Exception(message)

private val ASCII: Charset = Charset.forName("US-ASCII")

class FastbootClient(
    private val connection: UsbDeviceConnection,
    private val bulkIn: UsbEndpoint,
    private val bulkOut: UsbEndpoint
) {
    private val timeoutMs = 10_000

    private fun sendRaw(bytes: ByteArray, len: Int = bytes.size, offset: Int = 0) {
        val sent = connection.bulkTransfer(bulkOut, bytes, offset, len, timeoutMs)
        if (sent != len) throw FastbootProtocolException("Échec d'envoi USB ($sent/$len octets).")
    }

    private fun readRaw(maxLen: Int = 64 * 1024): ByteArray {
        val buf = ByteArray(maxLen)
        val n = connection.bulkTransfer(bulkIn, buf, buf.size, timeoutMs)
        if (n < 0) throw FastbootProtocolException("Lecture USB échouée (câble débranché ou périphérique non réactif).")
        return buf.copyOf(n)
    }

    private fun splitResponse(resp: ByteArray): Pair<String, String> {
        if (resp.size < 4) throw FastbootProtocolException("Réponse fastboot trop courte.")
        val code = String(resp, 0, 4, ASCII)
        val payload = String(resp, 4, resp.size - 4, ASCII)
        return code to payload
    }

    /** Envoie une commande texte fastboot et lit les réponses INFO* jusqu'à OKAY/FAIL/DATA. */
    private fun command(cmd: String): Pair<String, String> {
        sendRaw(cmd.toByteArray(ASCII))
        while (true) {
            val (code, payload) = splitResponse(readRaw())
            when (code) {
                "INFO" -> continue // message d'info intermédiaire, on continue d'écouter
                "OKAY", "FAIL", "DATA" -> return code to payload
                else -> throw FastbootProtocolException("Code fastboot inconnu : $code")
            }
        }
    }

    fun getVar(name: String): String {
        val (code, payload) = command("getvar:$name")
        if (code != "OKAY") throw FastbootProtocolException("getvar:$name -> $code $payload")
        return payload
    }

    /** getvar:all renvoie une série de lignes INFO "nom: valeur" avant OKAY. */
    fun getAllVars(): Map<String, String> {
        val result = LinkedHashMap<String, String>()
        sendRaw("getvar:all".toByteArray(ASCII))
        while (true) {
            val (code, payload) = splitResponse(readRaw())
            if (code == "INFO") {
                val idx = payload.indexOf(':')
                if (idx > 0) result[payload.substring(0, idx).trim()] = payload.substring(idx + 1).trim()
            } else break
        }
        return result
    }

    fun rebootBootloader() { command("reboot-bootloader") }
    fun reboot() { command("reboot") }

    /** Efface une partition (ex. "userdata", "cache") — utilisé pour la réinitialisation d'usine guidée. */
    fun erase(partition: String): String {
        val (code, payload) = command("erase:$partition")
        if (code != "OKAY") throw FastbootProtocolException("erase:$partition -> $code $payload")
        return payload
    }

    /**
     * Flashe une partition en diffusant les données depuis un flux (évite de charger
     * toute l'image firmware en mémoire, utile pour les grosses images système).
     */
    fun flash(partition: String, totalSize: Int, input: InputStream, onProgress: ((Int) -> Unit)? = null): String {
        val sizeHex = String.format("%08x", totalSize)
        val (dlCode, dlPayload) = command("download:$sizeHex")
        if (dlCode != "DATA") throw FastbootProtocolException("download -> $dlCode $dlPayload")

        val buffer = ByteArray(16 * 1024)
        var sentTotal = 0
        while (sentTotal < totalSize) {
            val read = input.read(buffer)
            if (read <= 0) break
            sendRaw(buffer, read)
            sentTotal += read
            onProgress?.invoke((sentTotal.toLong() * 100 / totalSize.coerceAtLeast(1)).toInt())
        }
        if (sentTotal != totalSize) throw FastbootProtocolException("Transfert incomplet : $sentTotal/$totalSize octets envoyés.")

        val (finCode, finPayload) = splitResponse(readRaw())
        if (finCode != "OKAY") throw FastbootProtocolException("Fin de download -> $finCode $finPayload")

        val (flCode, flPayload) = command("flash:$partition")
        if (flCode != "OKAY") throw FastbootProtocolException("flash:$partition -> $flCode $flPayload")
        return flPayload
    }
}
