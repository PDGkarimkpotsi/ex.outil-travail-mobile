package com.afribdstudio.outiltravailmobile

import android.content.Context
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyPair
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import javax.crypto.Cipher

class AdbProtocolException(message: String) : Exception(message)

/**
 * Client ADB minimal (rôle "hôte"), implémentant uniquement ce qui est
 * nécessaire à un diagnostic en lecture et à un redémarrage guidé :
 * handshake CNXN/AUTH, ouverture d'un flux "shell:<commande>", et fermeture.
 *
 * Cette classe réimplémente le protocole ADB tel que documenté publiquement
 * par le projet AOSP (system/core/adb). Elle ne contourne rien : tant que le
 * téléphone client n'a pas explicitement accepté la clé RSA de ce technicien
 * (fenêtre "Autoriser le débogage USB ?"), aucune commande ne passe.
 *
 * Implémentation écrite sans accès à un appareil physique pour la tester :
 * avant un usage en atelier, valide le handshake avec un téléphone de test
 * (Logcat côté `adbd` aide beaucoup en cas d'échec) et ajuste au besoin les
 * détails bas niveau (taille de blocs, format de la clé publique dans
 * AdbKeyStore).
 */
class AdbClient(
    private val connection: UsbDeviceConnection,
    private val bulkIn: UsbEndpoint,
    private val bulkOut: UsbEndpoint,
    private val keyPair: KeyPair
) {
    companion object {
        private const val A_SYNC = 0x434e5953
        private const val A_CNXN = 0x4e584e43
        private const val A_OPEN = 0x4e45504f
        private const val A_OKAY = 0x59414b4f
        private const val A_CLSE = 0x45534c43
        private const val A_WRTE = 0x45545257
        private const val A_AUTH = 0x48545541

        private const val AUTH_TOKEN = 1
        private const val AUTH_SIGNATURE = 2
        private const val AUTH_RSAPUBLICKEY = 3

        private const val MAX_PAYLOAD = 256 * 1024
        private const val VERSION = 0x01000000
    }

    private val timeoutMs = 15_000
    private var nextLocalId = 1
    private var connected = false

    private data class Packet(val command: Int, val arg0: Int, val arg1: Int, val data: ByteArray)

    private fun sendPacket(command: Int, arg0: Int, arg1: Int, data: ByteArray) {
        val header = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        var checksum = 0
        for (b in data) checksum += (b.toInt() and 0xFF)
        header.putInt(command); header.putInt(arg0); header.putInt(arg1)
        header.putInt(data.size); header.putInt(checksum); header.putInt(command.inv())
        val headerBytes = header.array()
        val sentHeader = connection.bulkTransfer(bulkOut, headerBytes, headerBytes.size, timeoutMs)
        if (sentHeader != headerBytes.size) throw AdbProtocolException("Échec d'envoi de l'en-tête ADB.")
        if (data.isNotEmpty()) {
            val sentData = connection.bulkTransfer(bulkOut, data, data.size, timeoutMs)
            if (sentData != data.size) throw AdbProtocolException("Échec d'envoi des données ADB.")
        }
    }

    private fun readPacket(): Packet {
        val headerBytes = ByteArray(24)
        val n = connection.bulkTransfer(bulkIn, headerBytes, headerBytes.size, timeoutMs)
        if (n != 24) throw AdbProtocolException("En-tête ADB invalide ou délai dépassé (vérifie que le câble reste branché).")
        val buf = ByteBuffer.wrap(headerBytes).order(ByteOrder.LITTLE_ENDIAN)
        val command = buf.int; val arg0 = buf.int; val arg1 = buf.int
        val dataLen = buf.int; buf.int /* checksum, ignoré en lecture */; buf.int /* magic */
        var data = ByteArray(0)
        if (dataLen > 0) {
            data = ByteArray(dataLen)
            var got = 0
            while (got < dataLen) {
                val chunk = ByteArray(minOf(16384, dataLen - got))
                val r = connection.bulkTransfer(bulkIn, chunk, chunk.size, timeoutMs)
                if (r <= 0) throw AdbProtocolException("Lecture de données ADB interrompue.")
                System.arraycopy(chunk, 0, data, got, r)
                got += r
            }
        }
        return Packet(command, arg0, arg1, data)
    }

    /** Signe le jeton envoyé par le téléphone client avec la clé privée (RSA brut, PKCS#1 v1.5 + préfixe SHA-1). */
    private fun signToken(token: ByteArray, privateKey: RSAPrivateKey): ByteArray {
        val sha1DigestInfoPrefix = byteArrayOf(
            0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a,
            0x05, 0x00, 0x04, 0x14
        )
        val toSign = sha1DigestInfoPrefix + token
        val keySizeBytes = (privateKey.modulus.bitLength() + 7) / 8
        val padLen = keySizeBytes - 3 - toSign.size
        if (padLen < 8) throw AdbProtocolException("Clé RSA trop courte pour signer le jeton ADB.")
        val block = ByteArray(keySizeBytes)
        block[0] = 0x00; block[1] = 0x01
        for (i in 0 until padLen) block[2 + i] = 0xFF.toByte()
        block[2 + padLen] = 0x00
        System.arraycopy(toSign, 0, block, 3 + padLen, toSign.size)

        val cipher = Cipher.getInstance("RSA/ECB/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, privateKey) // opération RSA brute = signature car on gère nous-mêmes le padding
        return cipher.doFinal(block)
    }

    /** Établit la connexion ADB. Si la clé n'est pas encore connue du téléphone client,
     *  celui-ci affichera la fenêtre d'autorisation : seul son propriétaire peut l'accepter. */
    fun connect(): String {
        sendPacket(A_CNXN, VERSION, MAX_PAYLOAD, "host::\u0000".toByteArray())
        var attempts = 0
        while (attempts < 4) {
            val pkt = readPacket()
            when (pkt.command) {
                A_CNXN -> { connected = true; return "Connecté : " + String(pkt.data).trimEnd('\u0000') }
                A_AUTH -> {
                    if (pkt.arg0 != AUTH_TOKEN) throw AdbProtocolException("Paquet AUTH inattendu.")
                    val priv = keyPair.private as RSAPrivateKey
                    val sig = signToken(pkt.data, priv)
                    sendPacket(A_AUTH, AUTH_SIGNATURE, 0, sig)
                    val next = readPacket()
                    if (next.command == A_CNXN) { connected = true; return "Connecté : " + String(next.data).trimEnd('\u0000') }
                    if (next.command == A_AUTH && next.arg0 == AUTH_TOKEN) {
                        // Clé encore inconnue du client : on envoie la clé publique.
                        val pub = keyPair.public as RSAPublicKey
                        val blob = AdbKeyStore.publicKeyToAdbBlob(pub)
                        sendPacket(A_AUTH, AUTH_RSAPUBLICKEY, 0, blob)
                        attempts++
                        continue
                    }
                    attempts++
                }
                else -> attempts++
            }
        }
        throw AdbProtocolException(
            "En attente de l'autorisation sur le téléphone client. Accepte « Autoriser le débogage USB ? » " +
            "à l'écran du téléphone client, puis relance la connexion."
        )
    }

    private fun ensureConnected() {
        if (!connected) throw AdbProtocolException("Non connecté : lance d'abord « Connecter en ADB ».")
    }

    /** Exécute une commande shell et renvoie sa sortie texte. */
    fun shell(cmd: String): String {
        ensureConnected()
        val localId = nextLocalId++
        sendPacket(A_OPEN, localId, 0, "shell:$cmd\u0000".toByteArray())
        var remoteId = 0
        val out = StringBuilder()
        var opened = false
        while (true) {
            val pkt = readPacket()
            when (pkt.command) {
                A_OKAY -> { remoteId = pkt.arg0; opened = true }
                A_WRTE -> {
                    remoteId = pkt.arg0
                    out.append(String(pkt.data, Charsets.UTF_8))
                    sendPacket(A_OKAY, localId, remoteId, ByteArray(0))
                }
                A_CLSE -> { if (opened) sendPacket(A_CLSE, localId, remoteId, ByteArray(0)); return out.toString() }
                else -> {}
            }
        }
    }

    /** Redémarre le téléphone client. mode = "" (normal), "recovery", "bootloader". */
    fun reboot(mode: String) {
        ensureConnected()
        val localId = nextLocalId++
        sendPacket(A_OPEN, localId, 0, "reboot:$mode\u0000".toByteArray())
    }
}
