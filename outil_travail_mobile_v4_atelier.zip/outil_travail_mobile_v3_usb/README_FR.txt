OUTIL DE TRAVAIL MOBILE — V3 USB — ÉDITION ATELIER RÉPARATION

CONTENU
- Projet Android Studio natif Kotlin (pas de calculatrice dans cette édition).
- Pont USB natif Android : énumération des appareils, détection d'interface
  ADB et Fastboot, demande d'autorisation système.
- Flashage officiel via Fastboot : lecture des variables du bootloader,
  envoi d'une image depuis un fichier choisi sur le téléphone technicien,
  redémarrage bootloader/normal.
- Diagnostic ADB en lecture seule : batterie, stockage, identification,
  temps depuis le dernier démarrage, avec suggestions automatiques.
- Réinitialisation d'usine guidée (via Fastboot), avec double confirmation
  et rappel explicite de la protection FRP.
- Scripts JS/Python (Pyodide en ligne au premier chargement), dossiers et
  fiches d'intervention avec consentement du client, conservés depuis la
  Bêta 2.

IMPORTANT : CE N'EST PAS ENCORE UN APK PRÊT À INSTALLER.
C'est le code source Android Studio. Ouvre ce dossier dans Android Studio,
laisse Gradle synchroniser (AGP 8.7.3 / Gradle 8.9), puis Build > Build
APK(s). Le wrapper gradle-wrapper.jar n'est pas fourni ; génère-le avec
`gradle wrapper --gradle-version 8.9` si Android Studio le demande.

CE QUE L'APPLICATION FAIT RÉELLEMENT
- Fastboot (protocole officiel, identique dans son principe à Odin ou aux
  platform-tools Android) : ne fonctionne QUE si le téléphone client est
  démarré en mode bootloader ET que son propriétaire a déjà activé le
  déverrouillage OEM / déverrouillé son bootloader. Sinon, le téléphone
  répond FAIL à toute commande flash/erase — l'application ne force rien.
- ADB : ne fonctionne QUE si le débogage USB est déjà activé côté client
  ET que son propriétaire accepte, sur son propre écran, la fenêtre
  « Autoriser le débogage USB ? ». Cette autorisation ne peut être donnée
  que par lui ; l'application ne peut ni l'activer ni la simuler.
- Réinitialisation d'usine : efface les données via Fastboot (erase
  userdata + cache), ce qui déclenche ensuite la vérification FRP
  (reconnexion du compte Google/Samsung précédemment synchronisé) — cette
  vérification n'est pas contournée.

CE QUE L'APPLICATION NE FAIT PAS ET NE FERA JAMAIS
- Elle ne lit, ne devine et ne contourne aucun mot de passe, verrou
  d'écran, schéma ou protection FRP.
- Elle n'active pas elle-même le débogage USB ni le déverrouillage OEM sur
  le téléphone client : ces réglages doivent déjà avoir été activés par
  son propriétaire, sur son appareil.
- Elle ne lit pas les SMS, comptes, photos ou fichiers privés du client.

LIMITES TECHNIQUES À CONNAÎTRE
- Le client Fastboot et le client ADB sont réimplémentés directement en
  Kotlin (transferts USB « bulk »), car l'environnement de développement
  utilisé pour écrire ce code n'avait pas accès à un téléphone physique
  pour les tester. Le protocole Fastboot (texte simple, sans
  cryptographie) est fiable. Le protocole ADB inclut un échange de clé
  RSA plus délicat (voir AdbKeyStore.kt / AdbClient.kt) : teste-le d'abord
  sur un téléphone de test avant un usage client, et consulte le Logcat
  d'Android Studio (filtre "adb" côté système) en cas d'échec de
  connexion — un ajustement mineur du format de clé publique peut être
  nécessaire selon les versions d'Android.
- Le diagnostic ADB se limite à des commandes shell en lecture seule
  (dumpsys battery, df, getprop, uptime). Il ne remplace pas un diagnostic
  matériel complet (micro-soudure, composants, etc.).
- Un téléphone avec bootloader verrouillé, débogage USB désactivé et code
  de verrouillage oublié ne peut pas être débloqué sans perte de données,
  par cette application ni par aucun outil légal — c'est une protection
  volontaire d'Android contre le vol.
- Le mode Python Pyodide utilise Internet pour charger son moteur la
  première fois ; il n'est pas embarqué hors ligne.
- Les fiches et dossiers restent dans le stockage local WebView. Exporter
  régulièrement une sauvegarde.

PROCÉDURE TYPE EN ATELIER
1. Ouvrir une fiche d'intervention avec le client (consentement, USB).
2. Brancher le téléphone client (câble de données + OTG si besoin).
3. Onglet USB direct > Rechercher, puis Demander l'autorisation Android.
4. Inspecter les informations USB : l'application indique si une interface
   ADB ou Fastboot est disponible, et guide vers la bonne action.
5. Selon le cas : lire les variables fastboot et flasher une image
   officielle, OU lancer le diagnostic ADB, OU guider une réinitialisation
   d'usine avec confirmation explicite.

RÉFÉRENCES TECHNIQUES
API Android USB Host : https://developer.android.com/develop/connectivity/usb/host
Protocole Fastboot (AOSP) : https://android.googlesource.com/platform/system/core/+/master/fastboot/
Protocole ADB (AOSP) : https://android.googlesource.com/platform/packages/modules/adb/+/refs/heads/main/OVERVIEW.TXT
